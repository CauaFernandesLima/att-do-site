function verificarSenhas(senha) {
    const minLength = 8;
    const temMaiuscula = /[A-Z]/.test(senha);
    const temMinuscula = /[a-z]/.test(senha);
    const temNumero = /[0-9]/.test(senha);
    const temCaractereEspecial = /[!@#$%^&*(),.?":{}|<>]/.test(senha);

    if (senha.length < minLength) {
        return false;
    }
    if (!temMaiuscula) {
        return false;
    }
    if (!temMinuscula) {
        return false;
    }
    if (!temNumero) {
        return false;
    }
    if (!temCaractereEspecial) {
        return false;
    }

    return true;
}


function lerESalidarSenha() {
    const senha = prompt("Por favor, insira sua senha:"); // Lê a senha do usuário
    const resultado = verificarSenhas(senha); // Chama a função de validação

    window.alert(resultado.mensagem); // Exibe o resultado da validação
}

function senhasIguais(senha1, senha2) {
    return senha1 === senha2;
}

// Função para ler as senhas e validá-las
function lerEValidarSenhas() {
    const senha1 = prompt("Por favor, insira sua senha:");
    const senha2 = prompt("Por favor, confirme sua senha:");

    // Verificar se as senhas são iguais
    if (!senhasIguais(senha1, senha2)) {
        window.alert("As senhas não são iguais.");
        return;
    }

    // Validar a senha
    const senhaValida = verificarSenhas(senha1);
    if (senhaValida) {
        window.alert("Senha válida.");
    } else {
        window.alert("Senha inválida.");
    }
}

module.exports={verificarSenhas,senhasIguais}