const { default: expect } = require('expect')
const {verificarSenhas,senhasIguais} = require('./script')

it('Testando se uma senha valida é valida', () => {
    expect(verificarSenhas("@Caua123456")).toBe(true)
})

it('Testando se uma senha invalida é valida', () => {
    expect(verificarSenhas("Caua123456")).toBe(false)
})

it('Testando se uma senha apenas com caracter especial é valida', () => {
    expect(verificarSenhas("@@@@@@@@@@")).toBe(false)
})

it('Testando se uma senha sem caracter especial é valida', () => {
    expect(verificarSenhas("Caua123456")).toBe(false)
})

it('Testando se uma senha somente com numeros é valida', () => {
    expect(verificarSenhas("12345678")).toBe(false)
})

it('Testando se uma senha sem numero é valida', () => {
    expect(verificarSenhas("@Cauaaaaaa")).toBe(false)
})

it('Testando se uma senha sem letra maiscula é valida', () => {
    expect(verificarSenhas("@caua123456")).toBe(false)
})

it('Testando se uma senha somente com letras minusculas é valida', () => {
    expect(verificarSenhas("ogaloganhou")).toBe(false)
})

it('Testando se uma senha somente com letras maiusculas é valida', () => {
    expect(verificarSenhas("NUUOGALOGAHNOU")).toBe(false)
})

it('Testando se uma senha sem minuscula é valida', () => {
    expect(verificarSenhas("@CAUA123456")).toBe(false)
})

it('Testando se uma senha sem 8 digitos é valida', () => {
    expect(verificarSenhas("@Caua1")).toBe(false)
})

it('testando se uma senha longa valida é reconhecida como valida', () => {
    expect(verificarSenhas ('@Cauaaaaaaaaaaaaaaaaaaaaaaaaaaa1234')).toBe(true)
})

it('testando se uma senha longa invalida é reconhecida como valida', () => {
    expect(verificarSenhas ('@Cauaaaaaaaaaaaaaaaaaaaaaaaaaaa')).toBe(false)
})

it('Testando se duas senhas iguais são reconhecidas como iguais', () => {
    expect(senhasIguais("admin123", "admin123")).toBe(true);
});

it('Testando se duas senhas diferentes são reconhecidas como diferentes', () => {
    expect(senhasIguais("admin123", "admin456")).toBe(false);
});

